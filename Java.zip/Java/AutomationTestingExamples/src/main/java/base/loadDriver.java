package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class loadDriver {
	public static WebDriver driver;
	public static Properties prop;
	public static FileInputStream fis;
	
	public static WebDriver chrome_driver() throws IOException {
		prop =  new Properties();
		fis = new FileInputStream(System.getProperty("user.dir")+"/src/main/java/base/config.properties");
		prop.load(fis);
		String driverPath = prop.getProperty("chrome_driver");
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/"+driverPath);
		ChromeOptions options = new ChromeOptions();
		options.addArguments("headless");
		driver = new ChromeDriver(options);
		driver.get(prop.getProperty("url"));
		return driver;
	}
}
