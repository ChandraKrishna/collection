package testselenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class mainClass {
	public static WebDriver driver;
	public static ChromeOptions option;
	
	@BeforeSuite
	public void initializeDriver() {

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Driver/chromedriver.exe");
		option = new ChromeOptions();
		option.addArguments("headless");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
		System.out.println("Driver Initialized");
	}
	
	public static void openUrl(String urlLink) {
		
		driver.get(urlLink);
		System.out.println("Link Opened");
	}
	
	@AfterMethod
	public void closeBrowser() {
		driver.close();
		System.out.println("Browser Closed");
	}
	
	@AfterSuite
	public void quitDriver() {
		driver.quit();
		System.out.println("Driver Closed");
	}
	
}
