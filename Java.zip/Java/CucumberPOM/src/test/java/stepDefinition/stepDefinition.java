package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import utilities.XLUtils;

public class stepDefinition {
	WebDriver driver = null;
	RequestSpecification httprequest;
	Response response;
	ChromeOptions options = new ChromeOptions();

	
	@Before
	public void initDriver() {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Driver\\chromedriver.exe");
	    options.addArguments("headless");
	}
	
	@After
	public void closeDriver() {
		driver.close();
	}
	
	@Given("^Launch Browser$")
	public void Launch_Browser() throws Throwable {
		driver = new ChromeDriver(options);
	}

	@When("^Enter the API Url with city name \"([^\"]*)\"$")
	public void enter_the_API_Url_with_city_name(String url) throws Throwable {
	    RestAssured.baseURI = "http://restapi.demoqa.com/utilities/weather/city";
	    httprequest = RestAssured.given();
	    String path = System.getProperty("user.dir")+"/TestData/city.xlsx";
	    int row = XLUtils.getRowCount(path, "Sheet1");
	    int col = XLUtils.getCellCount(path, "Sheet1", 1);
	    for (int i = 1 ; i <= row ; i++) {
	    	for (int j = 0 ; j < col ; j++) {
	    		String city = XLUtils.getCellData(path, "Sheet1", i, j);
	    		response = httprequest.request(Method.GET,"/"+city);
	    		Thread.sleep(1000);
	    		String datas = response.getBody().asString();
	    		String result = System.getProperty("user.dir")+"/TestData/result.xlsx";
	    		XLUtils.setCellData(result, "Sheet1", i, j+1, datas);
	    	}
	    }
	}

	@Then("^Validate Response$")
	public void validate_Response() throws Throwable {
		String path = System.getProperty("user.dir")+"/TestData/result.xlsx";
	    int row = XLUtils.getRowCount(path, "Sheet1");
	    int col = XLUtils.getCellCount(path, "Sheet1", 1);
	    for (int i = 1 ; i <= row ; i++) {
	    	for (int j = 0 ; j < col ; j++) {
	    		String city = XLUtils.getCellData(path, "Sheet1", i, j);
	    		System.out.println(city);
	    	}
	    }
	}
	

}
