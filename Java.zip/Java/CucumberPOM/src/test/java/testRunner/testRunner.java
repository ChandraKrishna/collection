package testRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Feature//feature.feature",
		glue = "stepDefinition",
		//dryRun = true,
		monochrome = true,
		format = {"pretty","html:Reports"}
		)

public class testRunner {
	
}
