$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Feature/feature.feature");
formatter.feature({
  "line": 1,
  "name": "Api Testing for Weather",
  "description": "Description: Weather Tests API",
  "id": "api-testing-for-weather",
  "keyword": "Feature"
});
formatter.before({
  "duration": 11188820,
  "status": "passed"
});
formatter.scenario({
  "line": 4,
  "name": "Weather Test API",
  "description": "",
  "id": "api-testing-for-weather;weather-test-api",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "Launch Browser",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Enter the API Url with city name \"http://restapi.demoqa.com/utilities/weather/city/noida\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Validate Response",
  "keyword": "Then "
});
formatter.match({
  "location": "stepDefinition.Launch_Browser()"
});
formatter.result({
  "duration": 2981481062,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "http://restapi.demoqa.com/utilities/weather/city/noida",
      "offset": 34
    }
  ],
  "location": "stepDefinition.enter_the_API_Url_with_city_name(String)"
});
formatter.result({
  "duration": 6945742703,
  "status": "passed"
});
formatter.match({
  "location": "stepDefinition.validate_Response()"
});
formatter.result({
  "duration": 131751032,
  "status": "passed"
});
formatter.after({
  "duration": 70943932,
  "status": "passed"
});
});