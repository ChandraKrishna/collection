package stepDefinition;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import utilities.XLUtils;

public class stepDefinition {
	WebDriver driver = null;
	RequestSpecification httprequest;
	Response response;
	ChromeOptions options = new ChromeOptions();

	
	@Before
	public void initDriver() throws Exception {
		System.out.println("1: Initialize Driver -------------------------------------------------------------------------");
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Driver\\chromedriver.exe");
	    options.addArguments("headless");
	    Thread.sleep(1000);
	    System.out.println("2: Initialized -------------------------------------------------------------------------");
	}
	
	@After
	public void closeDriver() {
		driver.close();
	}
	
	@Given("^Launch Browser$")
	public void Launch_Browser() throws Throwable {
		System.out.println("3: Launching Browser -------------------------------------------------------------------------");
		driver = new ChromeDriver(options);
		Thread.sleep(2000);
		System.out.println("4: Browser Launched -------------------------------------------------------------------------");
	}

	@When("^Enter the API Url with city name \"([^\"]*)\"$")
	public void enter_the_API_Url_with_city_name(String url) throws Throwable {
		System.out.println("5: Passing API -------------------------------------------------------------------------");
	    RestAssured.baseURI = "http://restapi.demoqa.com/utilities/weather/city";
	    httprequest = RestAssured.given();
	    String path = System.getProperty("user.dir")+"/TestData";
	    try {
	    	File check = new File(path+"/result.xlsx");
	    	boolean checkpoint = check.exists();
		     if (!checkpoint){
		    	 System.out.println("6: Result File Not Found -------------------------------------------------------------------------");
		    	 XLUtils.createBlankSheet(path, "result", "Sheet1");
		    	 XLUtils.setCellData(path, "result", "Sheet1", 1, 1, "Cities");
		    	 XLUtils.setCellData(path, "result", "Sheet1", 1, 2, "Response Data");
		    	 System.out.println("7: Result File Created -------------------------------------------------------------------------");
		     }
		     else{
		    	 System.out.println("8: Old Result File Found -------------------------------------------------------------------------");
		    	 File f = new File (path + "/result.xlsx");
		    	 f.delete();
		    	 System.out.println("9: Old Result Deleted -------------------------------------------------------------------------");
		    	 XLUtils.createBlankSheet(path, "result", "Sheet1");
		    	 XLUtils.setCellData(path, "result", "Sheet1", 1, 1, "Cities");
		    	 XLUtils.setCellData(path, "result", "Sheet1", 1, 2, "Response Data");
		    	 System.out.println("10: New Result File Created -------------------------------------------------------------------------");
		     }
	    	} catch (IOException e) {
	    		System.out.println("----------------------------------------Exception Occurred----------------------------------------");
		        e.printStackTrace();
		  }
	    int row = XLUtils.getRowCount(path, "city", "Sheet1");
	    for (int i = 2 ; i <= row ; i++) {
	    	int col = XLUtils.getColCount(path, "city", "Sheet1", i);
	    	for (int j = 1 ; j <= col ; j++) {
	    		System.out.println("11: Getting Cell Data -------------------------------------------------------------------------");
	    		String city = XLUtils.getCellData(path, "city", "Sheet1", i, j);
	    		System.out.println("12: Sending API Data -------------------------------------------------------------------------");
	    		response = httprequest.request(Method.GET,"/"+city);
	    		Thread.sleep(2000);
	    		System.out.println("13: Data Sent -------------------------------------------------------------------------");
	    		String datas = response.getBody().asString();
	    		Thread.sleep(1000);
	    		System.out.println("14: Getting Response Data -------------------------------------------------------------------------");
	    		Thread.sleep(100);
	    		System.out.println("15: Found Response Data -------------------------------------------------------------------------");
	    		System.out.println("16: Updating Result Output -------------------------------------------------------------------------");
	    		
	    		XLUtils.setCellData(path, "result", "Sheet1", i, j, city);
	    		Thread.sleep(1000);
	    		XLUtils.setCellData(path, "result", "Sheet1", i, j+1, datas);
	    		Thread.sleep(1000);
	    		System.out.println("17: Result Output Done : -------------------------------------------------------------------------");
	    	}
	    }
	}

	@Then("^Validate Response$")
	public void validate_Response() throws Throwable {
		String path = System.getProperty("user.dir")+"/TestData";
	    int row = XLUtils.getRowCount(path,"city", "Sheet1");
	    for (int i = 2 ; i <= row ; i++) {
	    	int col = XLUtils.getColCount(path, "city", "Sheet1", i);
	    	for (int j = 1 ; j <= col ; j++) {
	    		String city = XLUtils.getCellData(path, "result", "Sheet1", i, j);
	    		String data = XLUtils.getCellData(path, "result", "Sheet1", i, j+1);
	    		System.out.println(city.contains(data));
	    	}
	    }
	}
	
	@Then("^Copy")
	   public void copy() throws IOException {
			System.out.println("Copying Result To Desktop .........");
			File srcFile = new File(System.getProperty("user.dir")+"/TestData/result.xlsx");
			File destFile =  new File("C:\\Users\\Krishna.Chandra\\Desktop\\result.xlsx");
			FileUtils.copyFile(srcFile, destFile);
			System.out.println("Copied Result Done");
		}
	

}
