package programs;

public class evenOdd {

	public static void main(String[] args) {
		
		int i = 10;
		if(i%2==0) {
			System.out.print("No is Even");
		}
		else System.out.print("No is ODD");

	}

}
