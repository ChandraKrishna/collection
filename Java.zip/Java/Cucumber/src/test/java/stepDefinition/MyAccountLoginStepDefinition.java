package stepDefinition;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MyAccountLoginStepDefinition {
	
	
	@After
	public void close_Window() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    driver.close();
	}
	
	public WebDriver driver=null;
	
	@Given("^Open Browser$")
	public void open_Browser() throws Throwable {
	    System.setProperty("webdriver.chrome.driver", "C:\\Users\\Krishna.Chandra\\git\\repository\\CucumberRestAssuredBDD\\Drivers\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.manage().window().maximize();
	}

	/*@When("^Enter the Url \"([^\"]*)\"$")
	public void enter_the_Url(String arg1) throws Throwable {
	    driver.get("http://practice.automationtesting.in/");
	}*/
	
	@When("^Enter the Url \"([^\"]*)\"$")
	public void enter_the_Url(String url) throws Throwable {
	    driver.get(url);
	}

	@When("^Click on My Account Menu$")
	public void click_on_My_Account_Menu() throws Throwable {
	    driver.findElement(By.linkText("My Account")).click();
	}

	/*@When("^Go for Login and Enter Registered Username and Password$")
	public void go_for_Login_and_Enter_Registered_Username_and_Password() throws Throwable {
		driver.findElement(By.name("username")).sendKeys("pavanoltraining");
	    driver.findElement(By.name("password")).sendKeys("Test@selenium123");
	}*/
	
	/*@When("^Go for Login and Enter Registered Username \"([^\"]*)\" and Password \"([^\"]*)\"$")
	public void go_for_Login_and_Enter_Registered_Username_and_Password(String username, String password) throws Throwable {
		driver.findElement(By.name("username")).sendKeys(username);
	    driver.findElement(By.name("password")).sendKeys(password);
	}*/
	/*
	@When("^Go for Login and Enter Registered Username and Password$")
	public void go_for_Login_and_Enter_Registered_Username_and_Password(DataTable credential) throws Throwable {
	    List <List <String>> data = credential.raw();
	    driver.findElement(By.name("username")).sendKeys(data.get(0).get(0));
	    driver.findElement(By.name("password")).sendKeys(data.get(0).get(1));
	}*/
	
	@When("^Go for Login and Enter Registered Username and Password$")
	public void go_for_Login_and_Enter_Registered_Username_and_Password(DataTable credential) throws Throwable {
	    List<java.util.Map<String,String>> data = credential.asMaps(String.class, String.class);
	    driver.findElement(By.name("username")).sendKeys(data.get(0).get("user"));
	    driver.findElement(By.name("password")).sendKeys(data.get(0).get("password"));
	}


	@When("^Click on Login Button$")
	public void click_on_Login_Button() throws Throwable {
		driver.findElement(By.name("login")).click();
	}
	
	
	/*@Then("^User \"([^\"]*)\" must successfully Login to the Web Page$")
	public void user_must_successfully_Login_to_the_Web_Page(String username) throws Throwable {
	    String Expected = driver.findElement(By.xpath("//*[@id=\"page-36\"]/div/div[1]/div/p[1]/strong")).getText();
	    if(Expected.contains(username)) {
	    	Assert.assertEquals(true,Expected.contains(username));
	    }
	}*/
	
	@Then("^User must successfully Login to the Web Page$")
	public void user_must_successfully_Login_to_the_Web_Page() throws Throwable {
	    
	}

}
