package selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public class stepsDefinition {
	
	WebDriver driver;
	String dpath = System.getProperty("user.dir") + "/Driver/chromedriver.exe";
	String dstring = "webdriver.chrome.driver";
	
	@BeforeSuite
	public void beforeSuit() throws InterruptedException {
		System.out.println("Initializing Driver ..........................................");
		System.setProperty(dstring, dpath);
		driver = new ChromeDriver();
		System.out.println("Opening Browser ..........................................");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
	}
	
	@AfterSuite
	public void afterSuit() {
		System.out.println("Destroying Driver ..........................................");
		driver.quit();
	}
	
	
	@BeforeTest
	public void beforeTest() {
		System.out.println("Site Launching");
		driver.get("https://www.rahulshettyacademy.com/AutomationPractice/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("Site Launched");
	}
	
	@AfterTest
	public void afterTest() throws InterruptedException {
		System.out.println("Closing the Site");
		System.out.println("Closing Browser ..........................................");
		Thread.sleep(5000);
		driver.close();
	}
	
	@BeforeClass
	public void beforeClass() {
		System.out.println("Before Class");
	}
	
	@AfterClass
	public void afterClass() {
		System.out.println("After Class ");
	}
	
	@BeforeMethod
	public void beforeMethod() {
		System.out.println("Before Method ");
		
	}
	
	@AfterMethod
	public void afterMethod() {
		System.out.println("After Method ");
	}
}
