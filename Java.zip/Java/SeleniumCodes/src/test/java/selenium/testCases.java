package selenium;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class testCases extends stepsDefinition {
	
	@Test
	public void test1() throws InterruptedException {
		driver.findElement(By.xpath("(//input[@name='radioButton'])[2]")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("autocomplete")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("autocomplete")).sendKeys("India");
		Thread.sleep(2000);
		driver.findElement(By.id("dropdown-class-example")).click();
		Thread.sleep(2000);
		new Select(driver.findElement(By.id("dropdown-class-example"))).selectByVisibleText("Option3");
		Thread.sleep(2000);
		driver.findElement(By.id("checkBoxOption3")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("checkBoxOption1")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("openwindow")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("opentab")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("name")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("name")).sendKeys("Krishna");
		Thread.sleep(2000);
		driver.findElement(By.id("alertbtn")).click();
		Thread.sleep(2000);
	    assertEquals(closeAlertAndGetItsText(), "Hello Krishna, share this practice page and share your knowledge");
	    Thread.sleep(2000);
	    driver.findElement(By.id("confirmbtn")).click();
	    Thread.sleep(2000);
	    assertTrue(closeAlertAndGetItsText().matches("^Hello , Are you sure you want to confirm[\\s\\S]$"));
	    Thread.sleep(2000);
	    driver.findElement(By.id("hide-textbox")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("show-textbox")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("displayed-text")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("displayed-text")).sendKeys("Testing Box");
	    Thread.sleep(2000);
	    driver.findElement(By.id("show-textbox")).click();
	    Thread.sleep(2000);
	    Actions action = new Actions(driver);
	    WebElement element = driver.findElement(By.id("mousehover"));
	    Thread.sleep(2000);
	    action.moveToElement(element).perform();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Top")).click();
	    Thread.sleep(2000);
	    
	}

	private String closeAlertAndGetItsText() {
	    boolean acceptNextAlert = true;
		try {
	      Alert alert = driver.switchTo().alert();
	      String alertText = alert.getText();
	      if (acceptNextAlert) {
	        alert.accept();
	      } else {
	        alert.dismiss();
	      }
	      return alertText;
	    } finally {
	      acceptNextAlert = true;
	    }
	}
}
