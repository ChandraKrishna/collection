package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class XLUtils {

	public static XSSFWorkbook workbook;
	public static XSSFRow row;
	public static XSSFCell cell;
	

	public static void createBlankSheet (String FilePath, String Filename, String Sheetname) throws IOException 
	{
		XSSFWorkbook workbook = new XSSFWorkbook(); 
	    XSSFSheet spreadsheet = workbook.createSheet(Sheetname);
	    XSSFRow row = spreadsheet.createRow((short) 0);
	    row.createCell(0).setCellValue("");
	    FileOutputStream out = new FileOutputStream(new File(FilePath+"/"+Filename+".xlsx"));
	    workbook.write(out);
	    workbook.close();
	    out.close();
	}
	
	public static int getRowCount (String FilePath, String Filename, String Sheetname) throws IOException 
	{
	 	String file = FilePath+"/"+Filename+".xlsx";
	 	File check = new File(file);
	 	boolean checkpoint = check.exists();
	 	int rowcount = 0;
	 	if(checkpoint) 
	 	{
			FileInputStream in = new FileInputStream(new File(file));
			XSSFWorkbook workbook = new XSSFWorkbook(in); 
		    XSSFSheet spreadsheet = workbook.getSheet(Sheetname);
		    int first = spreadsheet.getFirstRowNum();
		    int last = spreadsheet.getLastRowNum();
		    rowcount = last - first;
		    rowcount = rowcount+1;
		    workbook.close();
		    in.close();
	 	} 
	 		else	{
	 					System.out.println("File Does not Exist at : "+ file);
	 				}
		return rowcount;
	}
	
	public static int getColCount (String FilePath, String Filename, String Sheetname , int rownum) throws IOException 
	{
	 	String file = FilePath+"/"+Filename+".xlsx";
	 	File check = new File(file);
	 	boolean checkpoint = check.exists();
	 	XSSFRow row;
	 	int colcount = 0;
	 	rownum = rownum - 1;
	 	if(checkpoint) 
	 	{
			FileInputStream in = new FileInputStream(new File(file));
			XSSFWorkbook workbook = new XSSFWorkbook(in); 
		    XSSFSheet spreadsheet = workbook.getSheet(Sheetname);
		    row = spreadsheet.getRow(rownum);
		    colcount = row.getLastCellNum();
		    workbook.close();
		    in.close();
	 	} 
	 		else	{
	 					System.out.println("File Does not Exist at : "+ file);
	 				}
		return colcount;
	}
	
	public static void setCellData (String FilePath, String Filename, String Sheetname, int rownum, int cellnum, String datavalue) throws IOException 
		{
		 	String file = FilePath+"/"+Filename+".xlsx";
		 	File check = new File(file);
		 	boolean checkpoint = check.exists();
		 	rownum = rownum - 1;
		 	cellnum = cellnum - 1;
		 	if(checkpoint) 
		 	{
				FileInputStream in = new FileInputStream(new File(file));
				XSSFWorkbook workbook = new XSSFWorkbook(in); 
			    FileOutputStream out = new FileOutputStream(new File(file));
			    XSSFSheet spreadsheet = workbook.getSheet(Sheetname);
			    XSSFRow row = spreadsheet.getRow(rownum);
			    if (row == null) {
			    	row = spreadsheet.createRow((short) rownum);
			    }
			    row.createCell(cellnum).setCellValue(datavalue);
			    workbook.write(out);
			    workbook.close();
			    in.close();
			    out.close();
		 	} 
		 		else	{
		 					System.out.println("File Does not Exist at : "+ file);
		 				}
		}
	
	public static String getCellData (String FilePath, String Filename, String Sheetname, int rownum, int cellnum) throws IOException 
	{
		String file = FilePath+"/"+Filename+".xlsx";
	 	File check = new File(file);
	 	boolean checkpoint = check.exists();
	 	XSSFRow row;
	 	XSSFCell col = null;
	 	rownum = rownum - 1;
	 	cellnum = cellnum - 1;
	 	String cellData = null;
		if(checkpoint) 
	 	{
	 		FileInputStream in = new FileInputStream(new File(file));
			XSSFWorkbook workbook = new XSSFWorkbook(in); 
		    XSSFSheet spreadsheet = workbook.getSheet(Sheetname);
		    row = spreadsheet.getRow(rownum);
		    col = row.getCell(cellnum);
		    try {
		    DataFormatter formatter = new DataFormatter();
			cellData = formatter.formatCellValue(col);
		    } catch (Exception e) {
				System.out.println(e);;
			}
		    workbook.close();
		    in.close();
	 	} 
	 		else	{
	 					System.out.println("File Does not Exist at : "+ file);
	 				}
		return cellData;
	}
	
	public static void readExcel (String FilePath, String Filename, String Sheetname) throws IOException 
	{
		String file = FilePath+"/"+Filename+".xlsx";
	 	File check = new File(file);
	 	boolean checkpoint = check.exists();
	 	int i = 0, j = 0 ;
		@SuppressWarnings("unused")
		int ccount = 0;
		if(checkpoint) 
	 	{
	 		FileInputStream in = new FileInputStream(file);
	 		workbook = new XSSFWorkbook(in);
	 		XSSFSheet spreadsheet =  workbook.getSheet(Sheetname);
	 		int start = spreadsheet.getFirstRowNum();
	 		int end = spreadsheet.getLastRowNum();
	 		int count = end - start;
	 		for(i = 0 ; i <= count ; i++) {
	 			row = spreadsheet.getRow(i);
	 			int cfirst = row.getFirstCellNum();
	 			int clast = row.getLastCellNum();
	 			ccount = clast - cfirst;
	 			for (j = cfirst ; j < clast ; j++) {
	 				cell = row.getCell(j);
	 				String temp = cell.getStringCellValue();
	 				System.out.print(" | " + temp);
	 				
	 			}
	 			System.out.println("");
	 		}
	 	} 
	 		else	{
	 					System.out.println("File Does not Exist at : "+ file);
	 				}
	}
	
}
