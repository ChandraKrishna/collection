package utility;

import java.io.IOException;

public class test {

	public static void main(String[] args) throws IOException {
	  
		  XLUtils.readExcel("C:\\Users\\Krishna.Chandra\\eclipse-workspace\\Projects\\ExcelUtility", "Writesheet", "Sheet");
		  
	}

}
