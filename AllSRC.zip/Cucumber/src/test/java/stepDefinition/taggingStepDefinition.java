package stepDefinition;

import cucumber.api.java.en.Given;

public class taggingStepDefinition {

	@Given("^this is valid login test$")
	public void this_is_valid_login_test() throws Throwable {
	    
	}

	@Given("^this is valid logout test$")
	public void this_is_valid_logout_test() throws Throwable {
	    
	}

	@Given("^this is search test$")
	public void this_is_search_test() throws Throwable {
	    
	}

	@Given("^this is advanced search test$")
	public void this_is_advanced_search_test() throws Throwable {
	    
	}

	@Given("^this is prepaid recharge test$")
	public void this_is_prepaid_recharge_test() throws Throwable {
	    
	}

	@Given("^this is postpaid recharge test$")
	public void this_is_postpaid_recharge_test() throws Throwable {
	    
	}


	
}
