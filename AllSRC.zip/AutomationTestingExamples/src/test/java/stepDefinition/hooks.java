package stepDefinition;



import cucumber.api.java.After;
import cucumber.api.java.Before;


public class hooks {
	@Before("@Sanity")
	public void Moblie() {
		System.out.print("BeforeHooks");
	}
	@After("@Sanity")
	public void Moblie2() {
		System.out.print("AfterHooks");
	}
}
