package stepDefinition;

import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import base.loadDriver;
import cucumber.api.java.en.*;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
public class stepDefinition {
	public static WebDriver driver;
	
	
	@Given("^given(\\d+)$")
	public void given(int arg1) throws Throwable {
		driver = loadDriver.chrome_driver();
	}

	@When("^when(\\d+)$")
	public void when(int arg1) throws Throwable {
	    
	}

	@Then("^then(\\d+)$")
	public void then(int arg1) throws Throwable {
	    
	}
	
	@Given("^ghh$")
	public void ghh() throws Throwable {
	    
	}

	@When("^jyhk$")
	public void jyhk() throws Throwable {
	    
	}

	@Then("^trhhygjukhh$")
	public void trhhygjukhh() throws Throwable {
	    
	}

	@Given("^gthtfh$")
	public void gthtfh() throws Throwable {
	    
	}

	@When("^hhhh$")
	public void hhhh() throws Throwable {
	    
	}

	@Then("^fgjhjj$")
	public void fgjhjj() throws Throwable {
	    
	}

	@Given("^hj$")
	public void hj() throws Throwable {
	    
	}

	@When("^fvgfghgh$")
	public void fvgfghgh() throws Throwable {
	    
	}

	@Then("^hjh$")
	public void hjh() throws Throwable {
	    
	}

	@Given("^jh$")
	public void jh() throws Throwable {
	    
	}

	@When("^hjkk$")
	public void hjkk() throws Throwable {
	    
	}

	@Then("^ikj$")
	public void ikj() throws Throwable {
	    
	}

	@Given("^rt$")
	public void rt() throws Throwable {
	   
	}

	@When("^ujhy$")
	public void ujhy() throws Throwable {
	   
	}

	@Then("^r(\\d+)$")
	public void r(int arg1) throws Throwable {
	    
	}

	@Given("^yyuy$")
	public void yyuy() throws Throwable {
	    
	}

	@When("^yy$")
	public void yy() throws Throwable {
	    
	}

	@Then("^yujiuy$")
	public void yujiuy() throws Throwable {
	    
	}


}
