package testselenium;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;
import org.apache.commons.io.FileUtils;

import ch.qos.logback.core.util.FileUtil;

public class testCases extends mainClass {

	WebElement element;
	
	/*
	@Test(priority = 1)
	public void login() {
		mainClass.openUrl("https://opensource-demo.orangehrmlive.com/");
		System.out.println("Base Url is : " + driver.getCurrentUrl());
		System.out.println("Tile of the Page is : " + driver.getTitle());
		element = driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/span"));
		String cred = element.getText();
		String[] arr = cred.split(" ");
		String user = arr[3];
		String pass = arr[7];
		driver.findElement(By.xpath("//input[@id=\"txtUsername\"]")).sendKeys(user);
		driver.findElement(By.xpath("//input[@id=\"txtPassword\"]")).sendKeys(pass);
		driver.findElement(By.xpath("//input[@id=\"btnLogin\"]")).click();
		System.out.println("Logged In");
	}
	*/
	/*
	@Test(priority = 2)
	public void googleSearch() throws InterruptedException {
		mainClass.openUrl("https://www.google.com/");
		System.out.println("Base Url is : " + driver.getCurrentUrl());
		System.out.println("Tile of the Page is : " + driver.getTitle());
		driver.findElement(By.xpath("/html/body/div/div[4]/form/div[2]/div[1]/div[1]/div/div[2]/input")).click();
		driver.findElement(By.xpath("/html/body/div/div[4]/form/div[2]/div[1]/div[1]/div/div[2]/input")).clear();
		driver.findElement(By.xpath("/html/body/div/div[4]/form/div[2]/div[1]/div[1]/div/div[2]/input")).sendKeys("ceo of google");
		driver.findElement(By.xpath("/html/body/div/div[4]/form/div[2]/div[1]/div[3]/center/input[1]")).click();
		Thread.sleep(2000);
		element = driver.findElement(By.className("Z0LcW"));
		assertEquals(element.getText(), "Sundar Pichai");
		driver.navigate().back();
		element = driver.findElement(By.xpath("/html/body/div/div[4]/form/div[2]/div[1]/div[3]/center/input[1]"));
		assertEquals(element.getTagName(), "input");
		driver.navigate().to("https://mail.google.com/mail/u/0/?pli=1#inbox");
		Thread.sleep(2000);
		System.out.println("Base Url is : " + driver.getCurrentUrl());
		System.out.println("Searched");
	}
	*/
	/*
	@Test(priority = 3)
	public void Action() throws InterruptedException {
		mainClass.openUrl("https://ksrtc.in/oprs-web/");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"bookingsForm\"]/div/div/div[2]/div[3]/button")).click();
		Thread.sleep(1000);
		System.out.println(driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();
		System.out.println("Alert Clicked");
	}
	*/
	/*
	@Test(priority = 4)
	public void Authentication() throws InterruptedException {
		Thread.sleep(1000);
		driver.get("https://admin:admin@the-internet.herokuapp.com/basic_auth");
		String message = driver.findElement(By.cssSelector("p")).getText();
		System.out.println(message);
	}
	*/
	
	@Test(priority = 3)
	public void ScreenShot() throws InterruptedException, IOException {
		String imageName = "sceenshot";
		mainClass.openUrl("http://krishnachandra.com/home/portfolio/");
		Thread.sleep(1000);
		TakesScreenshot ts  =((TakesScreenshot) driver);
		File src = ts.getScreenshotAs(OutputType.FILE);
		String screenShotLocation = System.getProperty("user.dir") + "/test-output/";
		File des = new File(screenShotLocation + imageName + ".png");
		FileUtils.copyFile(src, des);
		System.out.println("Screen Shot Taken");
	}
	
	
	
	
	
}
