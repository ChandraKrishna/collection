package myTestRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.*;

@RunWith(Cucumber.class)
@CucumberOptions(
		//features = "Features",
		features = "C://Users/Krishna.Chandra/git/repository/CucumberRestAssuredBDD/Features/Tagging.feature",
		glue = "stepDefinition",
		//format = {"pretty","html:html-output","json:json-output/cucumber.json","junit:xml-output/cucumber.xml"},
		//strict = false, //bypass the test if there is any steps is missed from feature file to step definition
		//dryRun = true, //to verify every steps are mentioned in step definition are not
		monochrome = true,// for clear result output
		//tags= {"@Sanity"} //Only
		//tags= {"@Sanity, @End2End"} //Or
		tags= {"@Sanity", "@End2End"} //And
		//tags= {"~@Sanity"} //Ignore
		)

public class TestRunner {

}
