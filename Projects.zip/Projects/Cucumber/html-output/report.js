$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("MyAccount-Login.feature");
formatter.feature({
  "line": 1,
  "name": "My Account Login",
  "description": "Description: This is a Login Page",
  "id": "my-account-login",
  "keyword": "Feature"
});
formatter.scenario({
  "comments": [
    {
      "line": 3,
      "value": "#HardCoded Parameters"
    },
    {
      "line": 4,
      "value": "#Scenario: Log in with valid username and password"
    },
    {
      "line": 5,
      "value": "#Given Open Browser"
    },
    {
      "line": 6,
      "value": "#When Enter the Url \"http://practice.automationtesting.in/\""
    },
    {
      "line": 7,
      "value": "#And Click on My Account Menu"
    },
    {
      "line": 8,
      "value": "#And Go for Login and Enter Registered Username and Password"
    },
    {
      "line": 9,
      "value": "#And Click on Login Button"
    },
    {
      "line": 10,
      "value": "#Then User must successfully Login to the Web Page"
    },
    {
      "line": 11,
      "value": "#Then Close Window"
    },
    {
      "line": 13,
      "value": "#Passing Parameters through feature file"
    }
  ],
  "line": 14,
  "name": "Log in with valid username and password",
  "description": "",
  "id": "my-account-login;log-in-with-valid-username-and-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "Open Browser",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "Enter the Url \"http://practice.automationtesting.in/\"",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "Click on My Account Menu",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "Go for Login and Enter Registered Username \"pavanoltraining\" and Password \"Test@selenium123\"",
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "Click on Login Button",
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "User must successfully Login to the Web Page",
  "keyword": "Then "
});
formatter.step({
  "line": 21,
  "name": "Close Window",
  "keyword": "Then "
});
formatter.match({
  "location": "MyAccountLoginStepDefinition.open_Browser()"
});
formatter.result({
  "duration": 4203018972,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "http://practice.automationtesting.in/",
      "offset": 15
    }
  ],
  "location": "MyAccountLoginStepDefinition.enter_the_Url(String)"
});
formatter.result({
  "duration": 9192411277,
  "status": "passed"
});
formatter.match({
  "location": "MyAccountLoginStepDefinition.click_on_My_Account_Menu()"
});
formatter.result({
  "duration": 3444517361,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "pavanoltraining",
      "offset": 44
    },
    {
      "val": "Test@selenium123",
      "offset": 75
    }
  ],
  "location": "MyAccountLoginStepDefinition.go_for_Login_and_Enter_Registered_Username_and_Password(String,String)"
});
formatter.result({
  "duration": 215787990,
  "status": "passed"
});
formatter.match({
  "location": "MyAccountLoginStepDefinition.click_on_Login_Button()"
});
formatter.result({
  "duration": 3074799624,
  "status": "passed"
});
formatter.match({
  "location": "MyAccountLoginStepDefinition.user_must_successfully_Login_to_the_Web_Page()"
});
formatter.result({
  "duration": 41628431,
  "status": "passed"
});
formatter.match({
  "location": "MyAccountLoginStepDefinition.close_Window()"
});
formatter.result({
  "duration": 2080496646,
  "status": "passed"
});
});