package programs;

public class primeNo {

	public static void main(String[] args) {
		int no = 57;
		int i = 0;
		int f = 0;
		for(i=4;i<no;i++) {
			if(no%i==0) {
				f = 1;
				break;
			}
		}
		if(f==1) {
			System.out.print("No is Not Prime");
		}else System.out.print("No is Prime");
	}

}
