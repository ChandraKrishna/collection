package selenium;

public class codes {

	public void codesTest() {

	}
	
}
