package main;

import cucumber.api.cli.Main;

public class run {
	
	public static void main(String[] args) throws Throwable, Exception {
		Main.main(new String[] { "-g", "stepDefinition",
        "C:\\Users\\Krishna.Chandra\\eclipse-workspace\\Projects\\CucumberRestAssuredFrameworkBDD\\Feature\\feature.feature",
        "-f","html:Reports"});
		
	}

}