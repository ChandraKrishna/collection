$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Feature/feature.feature");
formatter.feature({
  "line": 1,
  "name": "Api Testing for Weather",
  "description": "Description: Weather Tests API",
  "id": "api-testing-for-weather",
  "keyword": "Feature"
});
formatter.before({
  "duration": 1028783291,
  "status": "passed"
});
formatter.scenario({
  "line": 4,
  "name": "Weather Test API",
  "description": "",
  "id": "api-testing-for-weather;weather-test-api",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "Launch Browser",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Enter the API Url with city name \"http://restapi.demoqa.com/utilities/weather/city/\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Validate Response",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Copy",
  "keyword": "Then "
});
formatter.match({
  "location": "stepDefinition.Launch_Browser()"
});
formatter.result({
  "duration": 5308924501,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "http://restapi.demoqa.com/utilities/weather/city/",
      "offset": 34
    }
  ],
  "location": "stepDefinition.enter_the_API_Url_with_city_name(String)"
});
formatter.result({
  "duration": 24538468179,
  "status": "passed"
});
formatter.match({
  "location": "stepDefinition.validate_Response()"
});
formatter.result({
  "duration": 157425011,
  "status": "passed"
});
formatter.match({
  "location": "stepDefinition.copy()"
});
formatter.result({
  "duration": 126365692,
  "status": "passed"
});
formatter.after({
  "duration": 31268206,
  "status": "passed"
});
});